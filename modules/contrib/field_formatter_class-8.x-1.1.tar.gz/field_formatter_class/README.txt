Field Formatter Class
=====================
Provides third-party settings for field formatters, to allow site builders to add HTML classes to any field. Configurable per-display mode.
