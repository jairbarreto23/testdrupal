Glazed Subtheme Starterkit
See this page for documentation about subtheming Drupal: https://www.drupal.org/docs/8/theming-drupal-8/creating-a-drupal-8-sub-theme-or-sub-theme-of-sub-theme

SooperThemes Documentation: https://www.sooperthemes.com/hc/documentation