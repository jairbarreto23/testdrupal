# Developing

* Issues should be filed at http://drupal.org/project/issues/entity_embed
* Pull requests can be made against https://github.com/drupal-media/entity_embed/pulls
