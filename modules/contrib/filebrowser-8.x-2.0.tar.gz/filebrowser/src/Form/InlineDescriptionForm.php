<?php

namespace Drupal\filebrowser\Form;


class InlineDescriptionForm extends DescriptionForm {

}